import pyglet

from sandbox import Sandbox

if __name__ == '__main__':
    Sandbox()
    pyglet.app.run()